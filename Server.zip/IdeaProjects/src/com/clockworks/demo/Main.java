package com.clockworks.demo;

import java.io.*;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class Main {
    private static final Terminal terminal = new Terminal();
    public static int port;
    public static String authtoken;
    public static void makeBAT(){
        try  {
            Path path = Path.of(System.getProperty("user.home") + File.separator + "config.bat");
            if(Files.exists(path))
                Files.delete(path);
            Files.createFile(path);
            PrintWriter printWriter = new PrintWriter(System.getProperty("user.home") + File.separator + "config.bat");
            printWriter.println("@echo off\n" +
                    ":: BatchGotAdmin\n" +
                    "::-------------------------------------\n" +
                    "REM  --> Check for permissions\n" +
                    ">nul 2>&1 \"%SYSTEMROOT%\\system32\\cacls.exe\" \"%SYSTEMROOT%\\system32\\config\\system\"\n" +
                    "\n" +
                    "REM --> If error flag set, we do not have admin.\n" +
                    "if '%errorlevel%' NEQ '0' (\n" +
                    "    echo Requesting administrative privileges...\n" +
                    "    goto UACPrompt\n" +
                    ") else ( goto gotAdmin )\n" +
                    "\n" +
                    ":UACPrompt\n" +
                    "    echo Set UAC = CreateObject^(\"Shell.Application\"^) > \"%temp%\\getadmin.vbs\"\n" +
                    "    set params = %*:\"=\"\n" +
                    "    echo UAC.ShellExecute \"cmd.exe\", \"/c %~s0 %params%\", \"\", \"runas\", 1 >> \"%temp%\\getadmin.vbs\"\n" +
                    "\n" +
                    "    \"%temp%\\getadmin.vbs\"\n" +
                    "    del \"%temp%\\getadmin.vbs\"\n" +
                    "    exit /B\n" +
                    "\n" +
                    ":gotAdmin\n" +
                    "    pushd \"%CD%\"\n" +
                    "    CD /D \"%~dp0\"\n" +
                    "::--------------------------------------\n" +
                    "\n" +
                    "::ENTER YOUR CODE BELOW:" + "\n"+
                    "netsh advfirewall firewall add rule name=\"Transfer_in\" dir=in action=allow protocol=TCP localport=" +port + "\n" +
                    "netsh advfirewall firewall add rule name=\"Trasnfer_out\" dir=out action=allow protocol=TCP localport=" +port + "\n" +
                    "::END OF YOUR CODE::\n" +
                    "\n" +
                    "echo.\n" +
                    "echo...Script Complete....\n" +
                    "echo.\n" +
                    "\n" +
                    "pause");
            printWriter.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public static void makeBat2(){
        try {
            terminal.println("Enter ngrok authtoken:");
            authtoken = terminal.next();
            terminal.println("Enter port:");
            port = terminal.nextInt();
            Path path = Path.of(System.getProperty("user.home") + File.separator + "data" +File.separator + "ngrok" + File.separator + "ngrocc.bat");
            String path2 = System.getProperty("user.home") + File.separator + "data" +File.separator + "ngrok" + File.separator;
            if(Files.exists(path))
                Files.delete(path);
            Files.createFile(path);
            PrintWriter pw = new PrintWriter(System.getProperty("user.home") + File.separator + "data" +File.separator + "ngrok" + File.separator + "ngrocc.bat");
            pw.println("cd " + path2);
            pw.println("ngrok.exe authtoken " + authtoken);
            pw.println("ngrok.exe tcp " + port);
            pw.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public static void downloadNgrok() throws MalformedURLException {
        URL url = new URL("https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-windows-amd64.zip");
        try {
                BufferedInputStream in = new BufferedInputStream(url.openStream());
             Path path = Path.of(System.getProperty("user.home") + File.separator + "data");
             if(!Files.exists(path)){
                 Files.createDirectory(path);
             }
             FileOutputStream fileOutputStream = new FileOutputStream(System.getProperty("user.home")+ File.separator + "data" + File.separator + "ngrok.zip");
                byte dataBuffer[] = new byte[1024];
                int bytesRead;
                while ((bytesRead = in.read(dataBuffer, 0, 1024)) != -1) {
                    fileOutputStream.write(dataBuffer, 0, bytesRead);
                }
                terminal.println("Downloaded ngrok.");
        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }
    public static File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
        File destFile = new File(destinationDir, zipEntry.getName());

        String destDirPath = destinationDir.getCanonicalPath();
        String destFilePath = destFile.getCanonicalPath();

        if (!destFilePath.startsWith(destDirPath + File.separator)) {
            throw new IOException("Entry is outside of the target dir: " + zipEntry.getName());
        }
        terminal.println("Unzipped.");
        return destFile;
    }
    public static void unzip() throws IOException {
        String fileZip = System.getProperty("user.home")+ File.separator + "data" + File.separator + "ngrok.zip";
        File destDir = new File(System.getProperty("user.home")+ File.separator + "data" + File.separator + "ngrok");
        byte[] buffer = new byte[1024];
        ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip));
        ZipEntry zipEntry = zis.getNextEntry();
        while (zipEntry != null) {
            File newFile = newFile(destDir, zipEntry);
            if (zipEntry.isDirectory()) {
                if (!newFile.isDirectory() && !newFile.mkdirs()) {
                    throw new IOException("Failed to create directory " + newFile);
                }
            } else {
                // fix for Windows-created archives
                File parent = newFile.getParentFile();
                if (!parent.isDirectory() && !parent.mkdirs()) {
                    throw new IOException("Failed to create directory " + parent);
                }

                // write file content
                FileOutputStream fos = new FileOutputStream(newFile);
                int len;
                while ((len = zis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
                fos.close();
            }
            zipEntry = zis.getNextEntry();
        }
        zis.closeEntry();
        zis.close();
    }
    public static void main(String[] args) throws IOException, InterruptedException {
        ServerSocket serverSocket = null;
        downloadNgrok();
        unzip();
        Thread.sleep(1000);
        makeBat2();
        Runtime rt = Runtime.getRuntime();
        rt.exec("cmd /c start " + System.getProperty("user.home") + File.separator + "data" +File.separator + "ngrok" + File.separator + "ngrocc.bat");
        makeBAT();
        rt.exec("cmd /c start "+ System.getProperty("user.home") +File.separator + "config.bat");

    while (true) {
        UUID uuid = UUID.randomUUID();
        try {
            serverSocket = new ServerSocket(port);
            terminal.println("Started socket and it's listening to port " + port);
        } catch (IOException ex) {
           terminal.println("Can't setup server on this port number. ");
        }
        Socket socket = null;
        InputStream in = null;
        OutputStream out = null;

        try {
            socket = serverSocket.accept();
            terminal.println("Client Connected.");
        } catch (IOException ex) {
            terminal.println("Can't accept client connection. ");
        }

        try {
            in = socket.getInputStream();
        } catch (IOException ex) {
            terminal.println("Can't get socket input stream. ");
        }
        try {
            File file = new File(System.getProperty("user.home") + File.separator + "data");
            if(!file.exists()){
                file.mkdirs();
            }
            out = new FileOutputStream(System.getProperty("user.home") + File.separator + "data" + File.separator + uuid + ".txt");
        } catch (FileNotFoundException ex) {
            terminal.println("File not found.");
        }
        byte[] bytes = new byte[16 * 1024];
        int count;
        while ((count = in.read(bytes)) > 0) {
            out.write(bytes, 0, count);
        }
        terminal.println("File transfered.");
        out.close();
        in.close();
        socket.close();
        serverSocket.close();
    }
    }
}


