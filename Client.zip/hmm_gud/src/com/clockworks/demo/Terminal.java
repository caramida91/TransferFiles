package com.clockworks.demo;

import javax.swing.*;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.WindowEvent;

public class Terminal {
    public JFrame frame;
    public JTextPane console;
    public JTextField input;
    public JScrollPane scrollPane;
    public StyledDocument document;

    public Terminal() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {

        }
        frame = new JFrame();
        frame.setTitle("Konsole");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        console = new JTextPane();
        console.setEditable(false);
        console.setFont(new Font("Courier New", Font.PLAIN, 16));
        console.setOpaque(false);

        document = console.getStyledDocument();

        input = new JTextField();
        input.setFont(new Font("Courier New", Font.PLAIN, 16));
        input.setBorder(BorderFactory.createLineBorder(Color.lightGray));
        input.setEditable(true);
        input.setForeground(Color.LIGHT_GRAY);
        input.setCaretColor(Color.WHITE);
        input.setOpaque(false);

        scrollPane = new JScrollPane(console);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);

        frame.getContentPane().setBackground(Color.BLACK);
        frame.add(input, BorderLayout.SOUTH);
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.setSize(1024, 768);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setVisible(true);

    }

    public void scrollBottom() {
        console.setCaretPosition(console.getDocument().getLength());
    }

    public void print(String s) {
        print(s, Color.white);
    }
    public void print(String s, Color c) {
        Style style = console.addStyle("Style", null);
        StyleConstants.setForeground(style, c);
        try {
            document.insertString(document.getLength(), s, style);
            scrollBottom();
        } catch (Exception ignored) {
        }
    }
    public void println(String s) {
        println(s, Color.white);
    }
    public void println(String s, Color c) {
        print(s + "\n", c);
    }

    public void clear() {
        try {
            document.remove(0, document.getLength());
        } catch (Exception ignored) {
        }
    }

    public String next() {
        input.getInputMap().put(KeyStroke.getKeyStroke("ENTER"), "Read");
        input.getActionMap().put("Read", show);
        String text = console.getText();
        String text2 = console.getText();
        while(text.equals(text2))
            text2 = console.getText();
        input.getInputMap().put(KeyStroke.getKeyStroke("ENTER"), "doNothing");
        input.getActionMap().put("doNothing", nothing);
        input.selectAll();
        return input.getText();
    }
    public int nextInt(){
        return Integer.parseInt(next());
    }
    public char nextChar(){
        return next().charAt(0);
    }

    public void close() {
        frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
    }

    Action show = new AbstractAction() {
        public void actionPerformed(ActionEvent e) {
            if(input.getText().length() >= 1) {
                println(input.getText(), Color.green);
                scrollBottom();
            }
        }
    };
    Action nothing = new AbstractAction() {
        @Override
        public void actionPerformed(ActionEvent e) { }
    };
}
