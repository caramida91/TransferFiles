package com.clockworks.demo;
import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
public class Main {
    private static Terminal terminal = new Terminal();
    public static List<String> findertxt(String dir){
        List<String> textFiles = new ArrayList<String>();
        File f = new File(dir);
        for(File file : f.listFiles()){
            if(file.getName().endsWith(".txt") || file.getName().endsWith(".mp4")){
                textFiles.add(file.getName());
            }
        }
        return textFiles;
    }
    public static List<String> findermp4(String dir){
        List<String> textFiles = new ArrayList<String>();
        File f = new File(dir);
        for(File file : f.listFiles()){
            if(file.getName().endsWith(".mp4")){
                textFiles.add(file.getName());
            }
        }
        return textFiles;
    }
    public static List<String> ls(String dir) throws IOException {
        List<String> files = new ArrayList<>();
        File file = new File(dir);
        for (File file1 : file.listFiles()) {
            files.add(file1.getName());
        }
        return files;
    }
    public static void send(String host ,int port,String path) throws IOException {
        Socket socket;
        File file = new File(path);
        socket = new Socket(host,port);
        byte[] bytes = new byte[16*1024];
        InputStream in = new FileInputStream(file);
        OutputStream out = socket.getOutputStream();
        int count;

            while ((count = in.read(bytes)) > 0) {
                out.write(bytes, 0, count);
            }
            out.close();
            in.close();
            socket.close();
    }
    public static File cd(String dir){
        Path path = Paths.get(dir);
        return path.toFile();
    }
    public static void saveLhost(String path ,String lhost) throws FileNotFoundException {
        PrintWriter pw = new PrintWriter(path);
        pw.println(lhost);
        pw.close();
    }
    public static void saveRhost(String path , int rport) throws FileNotFoundException {
        PrintWriter pw = new PrintWriter(path);
        pw.println(rport);
        pw.close();
    }
    public static String getLhost(String path) throws IOException {
        BufferedReader br =new BufferedReader(new FileReader(path));
        String line;
        String lhost = "";
        while ((line = br.readLine()) != null){
            lhost = line;
        }
        return lhost;
    }
    public static int getRport(String path)throws IOException{
        BufferedReader br = new BufferedReader(new FileReader(path));
        String line;
        int rport = 0;
        while ((line = br.readLine()) != null){
            rport = Integer.parseInt(line);
        }
        return rport;
    }
    public static void main(String[] args) throws IOException {
        Path path = Path.of(System.getProperty("user.home")+ File.separator + "data" +File.separator+"lhost.txt");
        Path path1 = Path.of(System.getProperty("user.home")+ File.separator + "data" +File.separator+"rport.txt");
        if(!Files.exists(path))
                Files.createDirectory(path);
        if(!Files.exists(path1))
                Files.createDirectory(path1);
        String s = System.getProperty("os.name");
        List<String> list = findertxt(System.getProperty("user.home"));
        List<String> list1 = findermp4(System.getProperty("user.home") + File.separator + "Videos");
        terminal.println("Write full path to your file or to your folder(default is set to " + System.getProperty("user.home") + " use cd):");
        String chooseFile = System.getProperty("user.home");
        String lhost;
        lhost = getLhost(path.toString());
        if(lhost == null){
            lhost = "";
        }
        int rport = 0;
        rport = getRport(path1.toString());
        while (true) {
            try {
                File f = new File(chooseFile);
                String command = terminal.next();
                String [] arg =  command.split("\\s+");
                switch (arg[0]){
                    default:
                        System.out.println("Write full path to file");
                        break;
                    case "ls":
                        for(String sr : ls(chooseFile)){
                            terminal.println(sr);
                        }
                        break;
                    case "cd":
                        f = cd(arg[1]);
                        chooseFile = arg[1];
                        terminal.println(arg[1]);
                        break;
                    case "send":
                            if(lhost.equalsIgnoreCase("") || rport == 0){
                                break;
                            }else {
                                File file = new File(arg[1]);
                                if(!file.isDirectory()){
                                    send(lhost , rport, arg[1]);
                                    break;
                                }else{
                                    terminal.println("Cannot send folders.");
                                    break;
                                }
                            }
                    case "close":
                         terminal.close();
                    case "lhost":
                        lhost = arg[1];
                        terminal.println("Set local host " + lhost);
                        saveLhost(path.toString() , lhost);
                        break;
                    case "rport":
                        rport = Integer.parseInt(arg[1]);
                        saveRhost(path1.toString(),rport);
                        terminal.println("Set remote port " + rport);
                        break;
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
